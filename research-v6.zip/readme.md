This is going to be a platform for students to easily upload their final year projects and make money from it.
