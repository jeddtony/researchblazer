<div class="card" >
    <div class="card-header">
        Featured
    </div>
    <ul class="list-group list-group-flush">
        <li class="list-group-item"> <a href="#"> Unapproved Projects </a></li>
        <li class="list-group-item"> <a href="#">Approved Projects</a></li>
        <li class="list-group-item"><a href="#"> Users</a></li>
        <li class="list-group-item"><a href="{{route('createTags')}}"> Tags</a></li>
        <li class="list-group-item"><a href="#"> Payments</a></li>
    </ul>
</div>