<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-12 col-md-7 py offset-md-1">
            <div class="row">
                <div class=" col-12 col-md-12">
            <h4 class="center-text"><?php echo e($project->title); ?></h4>
            <hr>
            <h5>Abstract:</h5>
            <p><?php echo e($project->abstract); ?></p>
                    <br>
                    <br>
                </div>
                <h5 class="center-text">Download complete project <a href="payment/project/<?php echo e($project->id); ?>" class="btn btn-primary"> Download <i class="fas fa-download"></i></a> </h5>
            </div>
            <br>
            <br>
            <div class="row">
                <div class="col-12 col-md-12">
                    <h5 class="center-text">Download selected chapters</h5>
                </div>
                <div class="col-1 col-md-2">Chapter</div>
                <div class="col-5 col-md-5 center-text">Title</div>
                <div  class="col-3 col-md-3">Number of pages</div>
                <div class="col-3 col-md-2">Download </div>
            </div>

            <?php $__currentLoopData = $project->chapters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chapter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row">
                <div class="col-1 col-md-2"><?php echo e($chapter->chapter); ?></div>
                <div class="col-5 col-md-5 center-text"><?php echo e($chapter->title); ?></div>
                <div  class="col-3 col-md-3"><?php echo e($chapter->number_of_pages); ?></div>
                <div class="col-3 col-md-2"><a href="#" class="btn btn-primary">Download <i class="fas fa-download"></i></a> </div>
            </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

        <div class="col-12 col-md-3">
            <?php echo $__env->make('partials.tags', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.projectapp', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>