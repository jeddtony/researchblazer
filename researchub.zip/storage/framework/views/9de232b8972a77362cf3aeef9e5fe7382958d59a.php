<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12 col-md-7 p-4 offset-md-1">
            <h3 class="center-text">Latest Projects </h3>3

            <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <h5> <a href="/projects/<?php echo e($project->id); ?>"><?php echo e($project->title); ?> </a></h5>
                
                    
                

                <span class="username"> By: <?php echo e($project->user->name); ?></span>
                <hr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php echo e($projects->links()); ?>

        </div>

        <!--- Tag Side Bar -->
        <div class="col-12 col-md-3">
            <?php echo $__env->make('partials.tags', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.projectapp', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>