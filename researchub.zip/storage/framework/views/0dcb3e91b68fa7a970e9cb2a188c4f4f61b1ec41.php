<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">

                    <div class="card-header">Enter Account Details</div>

                    <div class="card-body">
                        <form method="POST" action="<?php echo e(route('userAccount')); ?>">
                            <?php echo csrf_field(); ?>

                            <div class="form-group row">
                                <label for="email" class="col-md-4 col-form-label text-md-right">Account Name</label>

                                <div class="col-md-6">
                                    <input id="accountName" type="text" class="form-control<?php echo e($errors->has('accountName') ? ' is-invalid' : ''); ?>"
                                           name="accountName" value="<?php echo e($accountName); ?>" required autofocus>

                                    <?php if($errors->has('accountName')): ?>
                                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('accountName')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="password" class="col-md-4 col-form-label text-md-right">Account Number</label>

                                <div class="col-md-6">
                                    <input id="accountNumber" type="number" class="form-control<?php echo e($errors->has('accountNumber') ? ' is-invalid' : ''); ?>"
                                           value="}" name="accountNumber" required>

                                    <?php if($errors->has('accountNumber')): ?>
                                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('accountNumber')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <div class="col-md-6 offset-md-4">
                                    <div class="form-check">
                                        
                                        <select name="bank" class="custom-select">
                                            <option selected>Select your bank</option>
                                            <option value="FirstBank">First Bank</option>
                                            <option value="GTBank">Guarranty Trust Bank</option>
                                            <option value="ZenithBank">Zenith Bank</option>
                                            <option value="AccessBank">Access Bank</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group row mb-0">
                                <div class="col-md-8 offset-md-4">
                                    <button type="submit" class="btn btn-primary">
                                        Submit
                                    </button>

                                </div>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>