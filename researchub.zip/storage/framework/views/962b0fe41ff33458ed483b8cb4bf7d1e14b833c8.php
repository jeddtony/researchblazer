<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12 col-md-7 p-4 offset-md-1">
            <h3 class="center-text">Projects </h3>
            <div class="tab">
                <button class="tablinks" onclick="openCity(event, 'Popular')" id="defaultOpen">Popular</button>
                <button class="tablinks" onclick="openCity(event, 'Latest')">Latest</button>

            </div>

            <div id="Popular" class="tabcontent">
                <h4 class="center-text">Popular</h4>
                <?php $__currentLoopData = $populars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $popular): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <h5> <a href="/projects/<?php echo e($popular->id); ?>"><?php echo e($popular->title); ?> </a></h5>
                
                    
                    

                <span class="username"> By: <?php echo e($popular->user->name); ?></span>
                    <hr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div id="Latest" class="tabcontent">
                <h3 class="center-text">Latest</h3>
                <?php $__currentLoopData = $latests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $latest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <h5> <a href="/projects/<?php echo e($latest->id); ?>"> <?php echo e($latest->title); ?> </a></h5>
                    
                        
                    

                    <span class="username"> By: <?php echo e($latest->user->name); ?></span>
                    <hr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <h5><a href="projects/popular" id="popularLink">View all popular projects</a>
            <a href="projects/latest" id="latestLink">View all latest projects</a> </h5>
        </div>

        <!--- Tag Side Bar -->
<div class="col-12 col-md-3">
       <?php echo $__env->make('partials.tags', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.projectapp', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>