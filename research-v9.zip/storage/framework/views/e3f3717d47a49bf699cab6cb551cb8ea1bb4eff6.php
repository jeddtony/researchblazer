<?php $__env->startSection('content'); ?>

    <div class="container-fluid">
        <div class="row py-4">
            <div class="col-md-3">
                <?php echo $__env->make('partials.adminSideBar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>

            <div class="col-md-9">
                <?php if(session('status')): ?>
                    <div class="col-md-4 offset-md-2">
                        <div class="alert alert-success alert-dismissible fade show"
                             role="alert" >
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            <?php echo e(session('status')); ?>

                        </div>
                    </div>
                <?php endif; ?>
                <h4>
                    Create Tags
                </h4>
                
                <div class="row" id="app">
                    <div class="col-md-12">
                        <div class="row" style="padding-top: 20px; padding-left: 15px">
                            <div class="col-12 col-md-12">
                                <form action="<?php echo e(route('createTag')); ?>" method="POST" >
                                    <?php echo csrf_field(); ?>
                                    <label>Name:</label>
                                    <input type="text" name="name[]" class="form-control mb-2 mr-sm-2 col-md-8 col-12" required>

                                    <label>Name:</label>
                                    <input type="text" name="name[]" class="form-control mb-2 mr-sm-2 col-md-8 col-12" required>

                                    <label>Name:</label>
                                    <input type="text" name="name[]" class="form-control mb-2 mr-sm-2 col-md-8 col-12" required>

                                    <label>Name:</label>
                                    <input type="text" name="name[]" class="form-control mb-2 mr-sm-2 col-md-8 col-12" required>

                                    <label>Name:</label>
                                    <input type="text" name="name[]" class="form-control mb-2 mr-sm-2 col-md-8 col-12" required>

                                    <div class="py-4">
                                        <input type="submit" class=" btn btn-primary col-2 col-md-1">
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminapp', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>